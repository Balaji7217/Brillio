/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.annotation.Resource;
import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Queue;

/**
 *
 * @author balaj
 */
@WebServlet(urlPatterns = {"/myMsg"})
public class myMsg extends HttpServlet {

  @Resource (mappedName="jmsDemo/myMsgDest")
  private Queue demoMyMsgDest;
  @Resource (mappedName ="jmsDemo/myMsg")
  private ConnectionFactory queue;
   public void doGet(HttpServletRequest req, HttpServletResponse res){
       
       
        
       try{
           String str=req.getParameter("t1");
           
           PrintWriter out=res.getWriter();
           sendJMSMessageToMyMsgDest(str);
           out.println("<h1> name is queued</h1>");
                   
           out.println("demo");
       }
       catch(Exception e){
           System.out.println(e);
           
       }
    }
private void sendJMSMessageToMyMsgDest(String messageData)
{
    try{
    Connection  con = queue.createConnection();
    Session s = con.createSession();
    MessageProducer mp= s.createProducer((Destination) demoMyMsgDest);
    TextMessage  tm=s.createTextMessage();
    tm.setText(messageData);
    mp.send(tm);

    }
    catch(Exception e){
         System.out.println(e);
    }
}
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
 

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import dao.EmployeeDao;

public class EmpCrudController extends DispatchAction{
	
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		Empform e= (Empform)form;
		
		EmployeeDao dao=new EmployeeDao();
	    int i = dao.save(e.getId(),e.getName(), e.getEmail(), e.getAddress());
	    if(i!=0)
	    return mapping.findForward("success");
	    else
		 return mapping.findForward("failure");
	}
	
	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
	     Empform e= (Empform)form;
		
		EmployeeDao dao=new EmployeeDao();
	    boolean b = dao.update(e.getId(),e.getName(), e.getEmail(), e.getAddress());
	    
	    if(b==true)
	    return mapping.findForward("success");
	    else
	    return mapping.findForward("failure");
		
	}
	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		Empform e= (Empform)form;
		
		EmployeeDao dao=new EmployeeDao();
	    boolean b = dao.delete(e.getId());
	    
	    if(b==true)
	    return mapping.findForward("success");
	    else
	    return mapping.findForward("failure");
		
	}
	public ActionForward find(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		Empform e= (Empform)form;
		
		EmployeeDao dao=new EmployeeDao();
	  List list = dao.find(e.getId());
	  
	  request.setAttribute("list", list);
	    
	    
	    return mapping.findForward("find");
	
		  
		
	}
	public ActionForward findAll(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
          Empform e= (Empform)form;
		
		EmployeeDao dao=new EmployeeDao();
	  List list = dao.findAll();
	  
	  request.setAttribute("list", list);
	    
	    
	    return mapping.findForward("findall");
		
	}

}
